
# We are explicitly loading the base classes and the fields in order to maintain backwards
# compatibility with older modulat inputs that used the single file modular input
from .modular_input_base_class import *
from .fields import *

"""
Below is the version of this library. This copy was built on 'Fri, 1 Nov 2019 12:10:49 -0700'. The identifier is
'1572635449'
"""
__version__ = '2.1.8'
